<div class="container-fluid">
    <div class="navbar-header">
        <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
        <a href="javascript:void(0);" class="bars"></a>
        <a class="navbar-brand" href=""><strong>SISTEM INFORMASI KEUANGAN</strong></a>
    </div>
    <div class="collapse navbar-collapse" id="navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
            <li class="pull-right"><a><strong><?php echo "<span>".hari_ini(date('w')).", ".tgl_indo(date('Y-m-d')).", <span id='jam'></span>"; ?></strong></a></li>
        </ul>
    </div>
</div>